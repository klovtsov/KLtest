#!perl
use ParApi::ApiClient;

my ($keyFileName, $apiuserName, $host, $operation) = @ARGV[0..3];
my ($rc, $id, $msg, $count, @list, $item);

my $client = ParApi::ApiClient->new(host        => $host,
                                    keyFileName => $keyFileName,
                                    userName    => $apiuserName);


								
($rc, $count, $msg, @list ) = $client->listUsers(maxRows => 500, userName => "yk800");

foreach $item (@list) {
	print $item->{"userName"}, ";", $item->{"custom1"}, ";", $item->{"custom2"}, ";", $item->{"custom6"}, ";", $item->{"mobile"}, "\n";

}

