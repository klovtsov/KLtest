#!/bin/sh
cd `dirname $0`
stubmaker.pl file:$1
cat >script.pl << EOF
#!/usr/bin/perl
use HandlePWRequestService;

my \$certfile = "$2";
my \$certpw = "$3";
my \$system = "$4";
my \$account = "$5";

\$ENV{HTTPS_PKCS12_FILE} = \$certfile;
\$ENV{HTTPS_PKCS12_PASSWORD} = \$certpw;

my \$pwservice = new HandlePWRequestService;
my @rc = \$pwservice->handleRequestWS(\$system,\$account);
print "\$rc[1]";
EOF
perl script.pl
rm -f HandlePWRequestService.pm script.pl

