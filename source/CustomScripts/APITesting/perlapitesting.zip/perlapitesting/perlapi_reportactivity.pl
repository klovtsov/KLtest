#!perl
use ParApi::ApiClient;

my ($keyFileName, $apiuserName, $host, $operation) = @ARGV[0..3];
my ($rc, $id, $msg, $count, @list, $item);

my $client = ParApi::ApiClient->new(host        => $host,
                                    keyFileName => $keyFileName,
                                    userName    => $apiuserName);


print "\nNo date range\n";
								
($rc, $count, $msg, @list ) = $client->reportActivity(maxRows  => 5000, userName => "yk_ui", role => "Requestor", objectType => "Session", operation => "Kill Session");

foreach $item (@list) {
	print $item->{"userName"}, ";", $item->{"userFullName"}, ";", $item->{"roleUsed"}, ";",$item->{"objectType"}, ";",$item->{"operation"}, ";",$item->{"failed"}, ";", ,$item->{"target"}, ";", ,$item->{"details"}, ";", $item->{"rptUtcOffset"}, ";", $item->{"applianceName"}, "\n";

}

print "\nStart date specified\n";


($rc, $count, $msg, @list ) = $client->reportActivity(maxRows  => 5000, userName => "yk_ui", role => "Requestor", objectType => "Session", operation => "Kill Session", startDate => "20120828");

foreach $item (@list) {
	print $item->{"userName"}, ";", $item->{"userFullName"}, ";", $item->{"roleUsed"}, ";",$item->{"objectType"}, ";",$item->{"operation"}, ";",$item->{"failed"}, ";", ,$item->{"target"}, ";", ,$item->{"details"}, ";", $item->{"rptUtcOffset"}, ";", $item->{"applianceName"}, "\n";

}


print "\nStart and End date specified\n";

($rc, $count, $msg, @list ) = $client->reportActivity(maxRows  => 5000, userName => "yk_ui", role => "Requestor", objectType => "Session", operation => "Kill Session", startDate => "20120828", endDate => "20120830");

foreach $item (@list) {
	print $item->{"userName"}, ";", $item->{"userFullName"}, ";", $item->{"roleUsed"}, ";",$item->{"objectType"}, ";",$item->{"operation"}, ";",$item->{"failed"}, ";", ,$item->{"target"}, ";", ,$item->{"details"}, ";", $item->{"rptUtcOffset"}, ";", $item->{"applianceName"}, "\n";

}



