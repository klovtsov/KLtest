#!perl
use ParApi::ApiClient;

my ($keyFileName, $apiuserName, $host, $operation) = @ARGV[0..3];
my ($rc, $id, $msg, $count, @list, $item);

my $client = ParApi::ApiClient->new(host        => $host,
                                    keyFileName => $keyFileName,
                                    userName    => $apiuserName);


								
($rc, $count, $msg, @list ) = $client->addPwdRequest(systemName => "ykspb9449", accountName => "yk75", requestNotes => "hello");

print $msg;
