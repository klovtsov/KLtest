package cacheserverremoteaccess;

import java.io.File;
import java.io.IOException;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Holder;

import clyk.generated.HandlePWRequest;
import clyk.generated.HandlePWRequestService;

public class cacheserverremoteaccess {
	
		public cacheserverremoteaccess () {
			//Something
		}
	
		public static void main(String[] args) throws IOException {
			String password = CacheServerRemoteAccessJava(args[0]);
			System.out.println(password);
		}
		
		public static String CacheServerRemoteAccessJava(String ArgString) throws IOException
		{
		   
			String cwd = new File( "." ).getCanonicalPath();
			cwd = cwd + "\\scripts\\keys\\";
		
			//String cwd = "c:\\2\\";
			//String cwd = "c:\\5\\";
		  
	    	String[] args = ArgString.split(";");
	    
	    		    	
	    	String urlWsdl = "file:/" + cwd + args[0];
	    	
	    	String keyStore = cwd + args[1];
	    	System.out.println("keyStore: " + keyStore);
	    	
	    	String keyStorePassword = args[2];
	    	System.out.println("keyStorePassword: " + keyStorePassword);
	    	
	    	String trustStore = cwd + args[3];
	    	System.out.println("trustStore: " + trustStore);
	    	
	    	String trustStorePassword = args[4];
	    	System.out.println("trustStorePassword: " + trustStorePassword);
	    	
	    	String systemName = args[5];
	    	System.out.println("systemName: " + systemName);
	    	
	    	String accountName = args[6];
	    	System.out.println("accountName: " + accountName);
	    	
	    	System.setProperty("javax.net.ssl.keyStore", keyStore);
	    	System.setProperty("javax.net.ssl.keyStoreType", "pkcs12");
	    	System.setProperty("javax.net.ssl.keyStorePassword", keyStorePassword);

	    // Need to convert parRootCA.crt downloaded from TPAM
	    // into jks type truststore using Java's keytool.
	    // keytool -importcert -trustcacerts -file parRootCA.crt -keystore truststore.jks
	    	System.setProperty("javax.net.ssl.trustStore", trustStore);
	    	System.setProperty("javax.net.ssl.trustStoreType", "jks");
	    	System.setProperty("javax.net.ssl.trustStorePassword", trustStorePassword);

	    		    	
	    	URL url = null;
			URL baseUrl;
			baseUrl = clyk.generated.HandlePWRequestService.class
						.getResource(".");
			url = new URL(baseUrl, urlWsdl);
	    	
	    	//HandlePWRequestService service = new HandlePWRequestService();
	    	
	    	HandlePWRequestService service = new HandlePWRequestService(url, new QName(
					"http://ejb3.pwAccel.edmz.com/", "HandlePWRequestService"));
	    	
	    	HandlePWRequest port = service.getHandlePWRequestPort();
	    	Holder<String> pw = new Holder<String>();

	    	int rc = port.handleRequestWS(systemName, accountName, pw);
	    	if (rc == 0)
	    	{
	    		//System.out.println(pw.value);
	    		return(pw.value);
	    	}
	    	else
	    	{
	    		//System.err.println("Request failed: rc=" + rc + ", msg=" + pw.value);
	    		return("Request failed: rc=" + rc + ", msg=" + pw.value);
	    	}
	  }

}
