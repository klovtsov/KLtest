#!perl
use ParApi::ApiClient;

my ($keyFileName, $apiuserName, $host, $operation) = @ARGV[0..3];
my ($rc, $id, $msg, $count, @list, $item);

my $client = ParApi::ApiClient->new(host        => $host,
                                    keyFileName => $keyFileName,
                                    userName    => $apiuserName);


								
($rc, $id, $msg) = $client->updatePsmAccount(system  => "ykaix5", account => "yk", minapprovers => 2);

print $msg;


