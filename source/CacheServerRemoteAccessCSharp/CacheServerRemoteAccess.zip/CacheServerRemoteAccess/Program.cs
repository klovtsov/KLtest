﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel;


namespace CacheServerRemoteAccess
{
    class Program
    {
        static void Main(string[] args)
        {
            // For testing, we'll accept the server certificate instead of
            // having to put the trusted root in our certificate store.
            ServicePointManager.ServerCertificateValidationCallback =
                (sender, certificate, chain, sslPolicyErrors) => true;

            // The configuration file created when adding the service reference
            // does not indicate that the client credential is certificate.  The
            // configuration file can be modified for this, or override as below.
            // Create a BasicHttpBinding and set credential type to certificate.
            var binding = new BasicHttpBinding(BasicHttpSecurityMode.Transport);
            binding.Security.Transport.ClientCredentialType =
                HttpClientCredentialType.Certificate;

            // The Cache is at 192.168.30.241.
            //var ea = new EndpointAddress
            //    ("https://10.30.44.48/HandlePWRequestService/HandlePWRequest");

            var ea = new EndpointAddress (args[0]);

            // Get a reference to the web service.
            var client = new HandlePWRequestReference.HandlePWRequestClient(binding, ea);

            // Get our client certificate.
            client.ClientCredentials.ClientCertificate.Certificate =
                new X509Certificate2(args[1], args[2]);

            string pw;
            // Invoke the web service to get the password.
            var rc = client.handleRequestWS(out pw, args[3], args[4]);
            if (rc == 0)
            {
                Console.WriteLine("{0}", pw);
            }
            else
            {
                Console.WriteLine("Request failed: rc={0}, msg={1}", rc, pw);
            }
        }

    }
}
