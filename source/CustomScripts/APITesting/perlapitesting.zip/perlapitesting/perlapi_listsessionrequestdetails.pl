#!perl
use ParApi::ApiClient;

my ($keyFileName, $apiuserName, $host) = @ARGV[0..2];
my ($rc, $count, $msg, @results, $item);

my $client = ParApi::ApiClient->new(host        => $host,
                                    keyFileName => $keyFileName,
                                    userName    => $apiuserName);


								
($rc, $count, $msg, @results ) = $client->listSessionRequestDetails(status => "All", requestorName => "User=Myself");


foreach $item (@results) {

	print "MinPasswordApprovers: ", $item->{"minPasswordApprovers"}, "\n";
        print "MinSessiondApprovers: ", $item->{"minSessionApprovers"}, "\n";

	print "+++++++++++++++++++++++++++++";
}



print "ReturnCode: ", $rc, "\nMessage: ", $msg, "\n";


