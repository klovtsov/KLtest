#!perl
use ParApi::ApiClient;

my ($keyFileName, $apiuserName, $host, $operation) = @ARGV[0..3];
my ($rc, $id, $msg, $count, @list, $item);

my $client = ParApi::ApiClient->new(host        => $host,
                                    keyFileName => $keyFileName,
                                    userName    => $apiuserName);


								
($rc, $msg) = $client->updateSyncPass(syncPassName => yksynccli5, changeFrequency => "-1", changeTime => "17:15", checkFlag => "N", disableFlag => "N", description => "HelloAgainnnn", 
password => "Q1w2e3r4t6", passwordRule => yk_rule2, releaseNotifyEmail => "yk\@quest55.com", resetFlag => "N", nextChangeDate => "03/05/2013", 
releaseChangeFlag => "N", releaseDuration => "60");

print $msg;