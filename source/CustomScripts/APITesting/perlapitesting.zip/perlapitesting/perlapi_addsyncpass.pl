#!perl
use ParApi::ApiClient;

my ($keyFileName, $apiuserName, $host, $operation) = @ARGV[0..3];
my ($rc, $id, $msg, $count, @list, $item);

my $client = ParApi::ApiClient->new(host        => $host,
                                    keyFileName => $keyFileName,
                                    userName    => $apiuserName);


								
($rc, $msg) = $client->addSyncPass(syncPassName => yksynccli5, changeFrequency => "0", changeTime => "15:15", checkFlag => "Y", disableFlag => "Y", description => "Hello", 
password => "Q1w2e3r4t5", passwordRule => yk_rule, releaseNotifyEmail => "yk\@quest.com", resetFlag => "Y", nextChangeDate => "03/03/2013", 
releaseChangeFlag => "Y", releaseDuration => "30");

print $msg;