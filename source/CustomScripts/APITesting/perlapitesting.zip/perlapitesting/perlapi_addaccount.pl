#!perl
use ParApi::ApiClient;

my ($keyFileName, $apiuserName, $host, $operation) = @ARGV[0..3];
my ($rc, $id, $msg, $count, @list, $item);

my $client = ParApi::ApiClient->new(host        => $host,
                                    keyFileName => $keyFileName,
                                    userName    => $apiuserName);


								
($rc, $id, $msg) = $client->addAccount(system  => "ykWintest", account => "yktest1");

print $msg;

($rc, $id, $msg) = $client->addAccount(system  => "ykWintest", account => "yktest2", changeTaskFlag => "Y");

print $msg;

($rc, $id, $msg) = $client->addAccount(system  => "ykWintest", account => "yktest3", changeTaskFlag => "N");

print $msg;