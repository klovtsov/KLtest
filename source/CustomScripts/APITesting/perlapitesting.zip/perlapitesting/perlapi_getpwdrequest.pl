#!perl
use ParApi::ApiClient;

my ($keyFileName, $apiuserName, $host, $operation, %hashresult) = @ARGV[0..3];
my ($rc, $id, $msg, $count, @list, $item);

my $client = ParApi::ApiClient->new(host        => $host,
                                    keyFileName => $keyFileName,
                                    userName    => $apiuserName);


								
($rc, $msg, %hashresult ) = $client->getPwdRequest(requestID => "1-137");

print "ReturnCode: ", $rc, "\nMessage: ", $msg, "\n";

print "Request Status: ", $hashresult{requestStatus}, "\n";

print "MinApprovers: ", $hashresult{minApprovers}, "\n";


