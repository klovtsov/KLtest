#!perl
use ParApi::ApiClient;

my ($keyFileName, $apiuserName, $host) = @ARGV[0..2];
my ($rc, $id, $msg, $count, @list, $item);

my $client = ParApi::ApiClient->new(host        => $host,
                                    keyFileName => $keyFileName,
                                    userName    => $apiuserName);


								
($rc, $id, $msg) = $client->addSessionRequest(systemName => "ykspb9449", accountName => "yk95", requestNotes => "hello");

print $msg;
