In the project, you have to Add Service Reference by specifying an URL to your wsdl file. For example, http://10.30.46.121/cache80.wsdl
