#!/usr/bin/perl

my $cliuserName = "ykapiadmin5"; 
my $keyFileName = "id_dsa_ykapiadmin5209";
my $host = "10.30.44.209";

my $systemName = "yk_tpamjavatesting"; 
my $networkAddress = "10.30.46.143"; 
my $platformName = "AIX"; 
my $functionalAccount = "Administrator"; 
my $funcAcctCred = "master"; 
my $timeout = 60;

my $accountName = "yk";
my $accountPassword = "Q1w2e3r4";
my $numberOfObjects = 5;
my $count, $start, $finish;

system("rm -f log.txt");

for ($count=1; $count<=$numberOfObjects; $count++) {
  system("java -jar tpamjavaapicmd.jar 'id_dsa_ykapiadmin5209;ykapiadmin5;10.30.44.209;deleteSystem;$systemName$count' 2>&1 1>>log.txt &");
  system("java -jar tpamjavaapicmd.jar 'id_dsa_ykapiadmin5209;ykapiadmin5;10.30.44.209;deleteUser;$systemName$count' 2>&1 1>>log.txt &");
}


