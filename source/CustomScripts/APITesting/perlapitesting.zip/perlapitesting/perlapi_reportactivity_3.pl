#!perl
use ParApi::ApiClient;

my ($keyFileName, $apiuserName, $host, $operation) = @ARGV[0..3];
my ($rc, $id, $msg, $count, @list, $item);

my $client = ParApi::ApiClient->new(host        => $host,
                                    keyFileName => $keyFileName,
                                    userName    => $apiuserName);


								
($rc, $count, $msg, @list ) = $client->reportActivity();

foreach $item (@list) {
	print $item->{"userName"}, ";", $item->{"userFullName"}, ";", $item->{"roleUsed"}, ";",$item->{"objectType"}, ";",$item->{"operation"}, ";",$item->{"failed"}, ";", ,$item->{"target"}, ";", ,$item->{"details"}, ";", $item->{"rptUtcOffset"}, ";", $item->{"applianceName"}, "\n";

}

