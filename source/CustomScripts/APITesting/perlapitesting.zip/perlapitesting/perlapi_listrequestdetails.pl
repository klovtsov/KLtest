#!perl
use ParApi::ApiClient;

my ($keyFileName, $apiuserName, $host) = @ARGV[0..2];
my ($rc, $count, $msg, @results, $item);

my $client = ParApi::ApiClient->new(host        => $host,
                                    keyFileName => $keyFileName,
                                    userName    => $apiuserName);


								
($rc, $count, $msg, @results ) = $client->listRequestDetails(status => "All", requestorName => "User=Myself");


foreach $item (@results) {

	print "RequestID: ", $item->{"requestID"}, "\n";
	print "MinApprovers: ", $item->{"minApprovers"}, "\n";
	print "+++++++++++++++++++++++++++++\n";
}



print "ReturnCode: ", $rc, "\nMessage: ", $msg, "\n";


