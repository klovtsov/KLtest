#!/usr/bin/perl

my $cliuserName = "ykcliadmin"; 
my $keyFileName = "id_dsa_ykcliadmin.PPK";
my $host = "10.30.44.209";

my $systemName = "ykq2003ent8"; 
my $networkAddress = "10.30.46.143"; 
my $platformName = "Windows"; 
my $functionalAccount = "Administrator"; 
my $funcAcctCred = "master"; 
my $timeout = 60;

my $accountName = "yk";
my $accountPassword = "Q1w2e3r4";
my $numberOfAccounts = 100;
my $count, $start, $finish;

my $uiUser1 = "yk_ui";

my $commandLine = "./plink -i $keyFileName $cliuserName\@$host";


#system("$commandLine AddSystem --SystemName $systemName --NetworkAddress $networkAddress --PlatformName $platformName --FunctionalAccount $functionalAccount --FuncAcctCred $funcAcctCred --Timeout $timeout");

my $timeStart = localtime();


for ($count=1; $count<=$numberOfAccounts; $count++) {
   $start = localtime();
   print "Start for $accountName$count (local time): $start\n";	
   system("$commandLine AddPwdRequest --SystemName $systemName --AccountName $accountName$count --ForUserName $uiUser1 --RequestNotes Test");


   $finish = localtime();
   print "Finish for $accountName$count (local time): $finish\n";	
}

my $timeFinish = localtime();


print "Number of accounts: $numberOfAccounts; Start: $timeStart; Finish: $timeFinish \n";


#system("$commandLine DeleteSystem --SystemName $systemName");

