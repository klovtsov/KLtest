#!perl
use ParApi::ApiClient;

my ($keyFileName, $apiuserName, $host, $operation) = @ARGV[0..3];
my ($rc, $id, $msg, $count, @list, $item);

my $client = ParApi::ApiClient->new(host        => $host,
                                    keyFileName => $keyFileName,
                                    userName    => $apiuserName);


								
($rc, $id, $msg) = $client->updateUser(userName  => "yk_ui", custom1 => "Yuri", custom2 => "Kuniver", mobile => "345-323-45");

print $msg;

